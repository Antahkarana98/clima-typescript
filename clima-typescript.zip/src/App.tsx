import useWeather from './hooks/useWeather'
import styles from './App.module.css'
import Form from './components/Form/Form'
import WeatherDetail from './components/WeatherDetail/WeatherDetail'
import Spinner from './components/Spinner/Spinner'
import Alert from './components/Alert/Alert'

function App() {

  const { loading, hasWeather, notFound, weather, getWeather } = useWeather()

  return (
    <>
      <h1 className={styles.title}>Buscador clima</h1>

      <div className={styles.container}>
        <Form getWeather={getWeather} />
        
        { loading && <Spinner /> }
        { hasWeather && <WeatherDetail weather={weather} /> }
        { notFound && <Alert>Ciudad no encontrada</Alert> }
      </div>
    </>
  )
}

export default App
