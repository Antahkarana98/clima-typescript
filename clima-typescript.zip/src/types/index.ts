export type SearchType = {
  city: string
  country: string
}

export type CountryType = {
  code: string
  name: string
}